package com.example.airlines

import android.icu.util.Calendar
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Spinner
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val airportList = Utils.generateAirportList()
        val airportNamesList = ArrayList<String>()
        for (airport in airportList) {
            airportNamesList.add(airport.getFormattedName())
        }
        val adapter = ArrayAdapter (
            this,
            android.R.layout.simple_spinner_dropdown_item, airportNamesList
        )

    }
}
